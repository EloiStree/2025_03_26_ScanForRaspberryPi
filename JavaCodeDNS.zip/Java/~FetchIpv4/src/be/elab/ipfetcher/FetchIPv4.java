package be.elab.ipfetcher;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class FetchIPv4 {

        public static String getIPv4Address(String hostname) {
            try {
                InetAddress address = InetAddress.getByName(hostname);
                return address.getHostAddress();
            } catch (UnknownHostException e) {
                e.printStackTrace();
                return null;
            }
        }

        public static String[] getAllIPv4Addresses(String hostname) {
        try {
            InetAddress[] addresses = InetAddress.getAllByName(hostname);
            String[] ipv4Addresses = new String[addresses.length];
            for (int i = 0; i < addresses.length; i++) {
                ipv4Addresses[i] = addresses[i].getHostAddress();
            }
            return ipv4Addresses;
        } catch (UnknownHostException e) {
            e.printStackTrace();
                return null;
            }}
            
            public static String getFirstIPv4Address(String hostname) {
                try {
                    InetAddress[] addresses = InetAddress.getAllByName(hostname);
                    for (InetAddress address : addresses) {
                        String ip = address.getHostAddress();
                        if (ip.contains(".")) {
                            return ip;
                        }
                    }
                    return "";
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                    return "";
                }
            }

            public static void main(String[] args) { 
                 String ipv4Address = getFirstIPv4Address("raspberrypi.local");
                System.out.println("IPv4 Address: " + ipv4Address);

                String[] allIPv4Addresses = getAllIPv4Addresses("raspberrypi.local");
                System.out.println("All IPv4 Addresses:");
                if (allIPv4Addresses != null) {
                    for (String address : allIPv4Addresses) {
                        System.out.println(address);
                    }
                }
            }
}
